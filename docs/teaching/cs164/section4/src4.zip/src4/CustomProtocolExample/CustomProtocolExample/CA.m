//
//  CA.m
//  CustomProtocolExample
//
//  Created by Tommy MacWilliam on 3/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "CA.h"

@implementation CA

- (int)grade
{
    return 100;
}

- (void)distributeGrades:(NSArray *)grades toStudents:(NSArray *)students
{
    NSLog(@"Pfft, way ahead of you");
}

@end
