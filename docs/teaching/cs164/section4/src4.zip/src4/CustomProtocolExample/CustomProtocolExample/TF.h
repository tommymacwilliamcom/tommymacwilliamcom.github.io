//
//  TF.h
//  CustomProtocolExample
//
//  Created by Tommy MacWilliam on 3/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ViewController.h"

@interface TF : NSObject <GraderProtocol>

@end
