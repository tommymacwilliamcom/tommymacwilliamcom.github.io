//
//  Student+Description.h
//  Section2
//
//  Created by Christopher Gerber on 2/29/12.
//  Copyright (c) 2012 Harvard. All rights reserved.
//

#import "Student.h"

@interface Student (Description)

- (NSString *)description;

@end
