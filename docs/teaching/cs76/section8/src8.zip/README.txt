- Section3App0: fullscreen MapView

- Section3App1: MapView with defined starting point

- Section3App2: MapView with a single point annotation

- Section3App3: MapView with several customized annotation pin views

- Section3App4: core location to get user's location

- Section3App5: MPMoviePlayerController to play remote movie

- Section3App6: using a UIWebView to display multiple file formats

- Section3App7: MapView with several custom annotation views and overlays
