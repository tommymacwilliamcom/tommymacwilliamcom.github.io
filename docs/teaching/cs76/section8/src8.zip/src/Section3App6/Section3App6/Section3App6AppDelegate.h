/**
 *  Section3App6AppDelegate.h
 *  Section3App6
 *  Tommy MacWIlliam, 2011
 *
 */

#import <UIKit/UIKit.h>

@class MainViewController;

@interface Section3App6AppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet MainViewController *mainViewController;

@end
