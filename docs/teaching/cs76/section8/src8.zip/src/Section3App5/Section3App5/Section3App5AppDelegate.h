/**
 *  Section3App5AppDelegate.h
 *  Section3App5
 *  Tommy MacWilliam, 2011
 *
 */

#import <UIKit/UIKit.h>

@class Section3App5ViewController;

@interface Section3App5AppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet Section3App5ViewController *viewController;

@end
