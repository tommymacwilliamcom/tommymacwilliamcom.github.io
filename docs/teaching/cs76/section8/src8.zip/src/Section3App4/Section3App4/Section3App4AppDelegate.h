/**
 *  Section3App4AppDelegate.h
 *  Section3App4
 *  Tommy MacWilliam, 2011
 *
 */

#import <UIKit/UIKit.h>

@class Section3App4ViewController;

@interface Section3App4AppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet Section3App4ViewController *viewController;

@end
