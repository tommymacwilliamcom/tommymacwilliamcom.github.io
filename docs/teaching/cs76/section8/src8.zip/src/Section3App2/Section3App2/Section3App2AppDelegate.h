/**
 *  Section3App2AppDelegate.h
 *  Section3App2
 *  Tommy MacWilliam, 2011
 *
 */

#import <UIKit/UIKit.h>

@class Section3App2ViewController;

@interface Section3App2AppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet Section3App2ViewController *viewController;

@end
