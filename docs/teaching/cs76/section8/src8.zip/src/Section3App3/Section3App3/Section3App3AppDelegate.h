/**
 *  Section3App3AppDelegate.h
 *  Section3App3
 *  Tommy MacWilliam, 2011
 *
 */

#import <UIKit/UIKit.h>

@class Section3App3ViewController;

@interface Section3App3AppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet Section3App3ViewController *viewController;

@end
