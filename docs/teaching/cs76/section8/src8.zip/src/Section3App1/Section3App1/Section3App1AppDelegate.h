/**
 *  Section3App1AppDelegate.h
 *  Section3App1
 *  Tommy MacWilliam, 2011
 *
 */

#import <UIKit/UIKit.h>

@class Section3App1ViewController;

@interface Section3App1AppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet Section3App1ViewController *viewController;

@end
