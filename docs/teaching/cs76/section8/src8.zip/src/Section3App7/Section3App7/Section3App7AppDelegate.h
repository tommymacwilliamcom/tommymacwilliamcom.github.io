/**
 *  Section3App7AppDelegate.h
 *  Section3App7
 *  Tommy MacWilliam, 2011
 *
 */

#import <UIKit/UIKit.h>

@class Section3App7ViewController;

@interface Section3App7AppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet Section3App7ViewController *viewController;

@end
