package com.tommymacwilliam.section3app4;

import android.app.Activity;
import android.os.Bundle;

public class Section3App4 extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
}