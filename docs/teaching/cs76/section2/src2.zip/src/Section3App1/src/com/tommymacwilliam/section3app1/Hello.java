package com.tommymacwilliam.section3app1;

import android.app.Activity;
import android.os.Bundle;

public class Hello extends Activity {
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hello);
	}
}
