/**
 *  PhotoView.h
 *  Section4App8
 *  Tommy MacWilliam, 2011
 *
 */

#import <UIKit/UIKit.h>

@interface PhotoView : UIView {
    
}

@end
