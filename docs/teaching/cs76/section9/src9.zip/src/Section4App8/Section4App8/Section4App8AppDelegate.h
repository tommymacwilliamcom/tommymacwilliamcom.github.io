/**
 *  Section4App8AppDelegate.h
 *  Section4App8
 *  Tommy MacWilliam, 2011
 *
 */

#import <UIKit/UIKit.h>

@class Section4App8ViewController;

@interface Section4App8AppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet Section4App8ViewController *viewController;

@end
