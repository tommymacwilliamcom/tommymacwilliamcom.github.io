/**
 *  Section4App6AppDelegate.h
 *  Section4App6
 *  Tommy MacWilliam, 2011
 *
 */

#import <UIKit/UIKit.h>

@class Section4App6ViewController;

@interface Section4App6AppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet Section4App6ViewController *viewController;

@end
