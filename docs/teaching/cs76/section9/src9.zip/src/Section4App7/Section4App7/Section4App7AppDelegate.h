/**
 *  Section4App7AppDelegate.h
 *  Section4App7
 *  Tommy MacWilliam, 2011
 *
 */

#import <UIKit/UIKit.h>

@class Section4App7ViewController;

@interface Section4App7AppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet Section4App7ViewController *viewController;

@end
