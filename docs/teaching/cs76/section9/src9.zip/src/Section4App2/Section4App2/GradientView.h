/**
 *  GradientView.h
 *  Section4App2
 *  Tommy MacWilliam, 2011
 *
 */

#import <UIKit/UIKit.h>

@interface GradientView : UIView {
    
}

@end
