/**
 *  Section4App2AppDelegate.h
 *  Section4App2
 *  Tommy MacWilliam, 2011
 *
 */

#import <UIKit/UIKit.h>

@class Section4App2ViewController;

@interface Section4App2AppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet Section4App2ViewController *viewController;

@end
