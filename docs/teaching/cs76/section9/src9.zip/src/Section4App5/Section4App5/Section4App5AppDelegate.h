/**
 *  Section4App5AppDelegate.h
 *  Section4App5
 *  Tommy MacWilliam, 2011
 *
 */

#import <UIKit/UIKit.h>

@class Section4App5ViewController;

@interface Section4App5AppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet Section4App5ViewController *viewController;

@end
