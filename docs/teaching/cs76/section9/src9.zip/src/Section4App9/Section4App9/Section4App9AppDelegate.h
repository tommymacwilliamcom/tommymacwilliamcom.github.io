/**
 *  Section4App9AppDelegate.h
 *  Section4App9
 *  Tommy MacWilliam, 2011
 *
 */

#import <UIKit/UIKit.h>

@class Section4App9ViewController;

@interface Section4App9AppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet Section4App9ViewController *viewController;

@end
