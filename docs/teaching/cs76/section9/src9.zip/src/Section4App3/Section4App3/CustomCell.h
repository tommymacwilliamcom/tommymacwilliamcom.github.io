/**
 *  CustomCell.h
 *  Section4App3
 *  Tommy MacWilliam, 2011
 *
 */

#import <UIKit/UIKit.h>

@interface CustomCell : UIView {
    
}

@end
