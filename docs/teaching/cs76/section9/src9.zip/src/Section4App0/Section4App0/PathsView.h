/**
 *  PathsView.h
 *  Section4App0
 *  Tommy MacWilliam, 2011
 *
 */

#import <UIKit/UIKit.h>

@interface PathsView: UIView {
    
}

@end
