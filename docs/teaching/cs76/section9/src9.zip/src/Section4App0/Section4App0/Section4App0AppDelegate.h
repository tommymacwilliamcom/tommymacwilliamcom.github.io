/**
 *  Section4App0AppDelegate.h
 *  Section4App0
 *  Tommy MacWilliam, 2011
 *
 */

#import <UIKit/UIKit.h>

@class Section4App0ViewController;

@interface Section4App0AppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet Section4App0ViewController *viewController;

@end
