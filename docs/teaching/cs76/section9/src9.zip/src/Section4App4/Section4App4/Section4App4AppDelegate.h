/**
 *  Section4App4AppDelegate.h
 *  Section4App4
 *  Tommy MacWilliam, 2011
 *
 */

#import <UIKit/UIKit.h>

@class Section4App4ViewController;

@interface Section4App4AppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet Section4App4ViewController *viewController;

@end
