- Section4App0: shape drawing with core graphics

- Section4App1: shadows and state saving

- Section4App2: gradients

- Section4App3: customizing a UITableViewCell by setting one of its view properties

- Section4App4: customizing a UIButton by subclassing and overriding drawRect

- Section4App5: using the UIImagePickerController and delegate

- Section4App6: implicit Core Animation

- Section4App7: explicit Core Animation

- Section4App8: drawing images with core graphics

- Section4App9: integrating with other apps
