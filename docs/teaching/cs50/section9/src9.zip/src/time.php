<?php

echo date('h:i:s A');

?>