//
//  ViewController.h
//  MapAnnotationExample
//
//  Created by Tommy MacWilliam on 4/4/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MKMapView;

@interface ViewController : UIViewController

@property (strong, nonatomic) IBOutlet MKMapView *mapView;

@end
