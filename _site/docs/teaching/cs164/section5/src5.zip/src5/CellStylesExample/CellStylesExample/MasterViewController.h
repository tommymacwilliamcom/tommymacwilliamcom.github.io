/**
 *  MasterViewController.h
 *  CellStylesExample
 *
 *  Tommy MacWilliam <tmacwilliam@cs.harvard.edu>
 *
 */

#import <UIKit/UIKit.h>

@interface MasterViewController : UITableViewController

@end
