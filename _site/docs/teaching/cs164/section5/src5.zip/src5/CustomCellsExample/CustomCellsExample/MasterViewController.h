/**
 *  MasterViewController.h
 *  CustomCellsExample
 *
 *  Tommy MacWilliam <tmacwilliam@cs.harvard.edu>
 *
 */

#import <UIKit/UIKit.h>

@interface MasterViewController : UITableViewController

@property (weak, nonatomic) IBOutlet UITableViewCell *customCell;

@end
