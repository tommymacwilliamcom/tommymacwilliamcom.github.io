//
//  ViewController.h
//  TableViewExample
//
//  Created by Tommy MacWilliam on 3/28/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UITableViewController

@property (strong, nonatomic) IBOutlet UITableView *tableView;

@end
