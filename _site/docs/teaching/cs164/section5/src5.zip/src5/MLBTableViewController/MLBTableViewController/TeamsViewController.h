/**
 *  TeamsViewController.h
 *  MLBTableViewController
 *
 *  Tommy MacWilliam <tmacwilliam@cs.harvard.edu>
 *
 */

#import <UIKit/UIKit.h>

@interface TeamsViewController : UITableViewController

@property (strong, nonatomic) NSMutableDictionary *teams;

@end
