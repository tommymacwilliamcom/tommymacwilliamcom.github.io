/**
 *  DivisionsViewController.h
 *  MLBTableViewController
 *
 *  Tommy MacWilliam <tmacwilliam@cs.harvard.edu>
 *
 */

#import <UIKit/UIKit.h>


@interface DivisionsViewController : UITableViewController

@property (strong, nonatomic) NSMutableDictionary *divisions;

@end
