package com.tommymacwilliam.section4app4_2;

import android.app.Activity;
import android.os.Bundle;
import android.net.Uri;
import android.widget.TextView;

public class Section4App4_2 extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        // get the URI containing the phone number
        Uri intentUri = this.getIntent().getData();
        
        // make sure URI was given
        if (intentUri != null) {
        	// URI given as scheme://host/path/segments, so number is the host
    		String number = intentUri.getHost();
            TextView tv = (TextView) this.findViewById(R.id.textview);
            tv.setText("So you want to call " + number + ", eh?");
        }
        else {
        	TextView tv = (TextView) this.findViewById(R.id.textview);
            tv.setText("uri is null");
        }
    }      
}